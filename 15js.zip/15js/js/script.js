let fmg = document.querySelector(".fmg");
fmg.onclick = function(){
    location.reload(); return false;
}
