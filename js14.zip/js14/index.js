"use strict";

// 1
let spisok = ['chto', 'ara', 'one'];
let elem = document.getElementById('elem');
for (let i=0; i<spisok.length; i++) {
	let li = document.createElement('li');
	li.textContent = spisok[i];
	elem.appendChild(li)
}
// 2
let newli = document.getElementsByTagName('li');
for (let i=0; i<spisok.length; i++) {
	newli[i].onclick = function() {
		event.currentTarget.textContent = spisok[i];
		alert(spisok[i])
	}
}
// 3 4
let tab = document.getElementById('tab');
for (let i=0; i<5; i++) {
	let tr = document.createElement('tr');
	for (let i=0; i<5; i++) {
		let td = document.createElement('td');
		td.textContent = 'x'
		tr.appendChild(td)
	}
	tab.appendChild(tr)
}
// 5
let tabl = document.getElementById('tabl');
let n = 1;
for (let i=0; i<5; i++) {
	let tr = document.createElement('tr');
	for (let i=0; i<5; i++) {
		let td = document.createElement('td');
		td.textContent = n
		n++
		tr.appendChild(td)
	}
	tabl.appendChild(tr)
}